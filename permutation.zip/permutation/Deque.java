import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
    private Node curr;
    private Node tail;
    private Node head;
    private int n;

    private class Node {
        Item item;
        Node next;
        Node prev;
    }

    // construct an empty deque
    public Deque() {
    }

    // is the deque empty?
    public boolean isEmpty() {
        return head == null;
    }

    // return the number of items on the deque
    public int size() {
        return n;
    }

    // add the item to the front
    public void addFirst(Item item) {
        if (item == null) throw new IllegalArgumentException();

        curr = head;
        head = new Node();
        head.item = item;
        head.next = curr;
        if (tail == null) tail = head;
        else curr.prev = head;
        n++;
    }

    // add the item to the back
    public void addLast(Item item) {
        if (item == null) throw new IllegalArgumentException();

        curr = tail;
        tail = new Node();
        tail.item = item;
        tail.prev = curr;
        if (isEmpty()) head = tail;
        else curr.next = tail;
        n++;
    }

    // remove and return the item from the front
    public Item removeFirst() {
        if (isEmpty()) throw new NoSuchElementException();

        if (n == 1) {
            Item item = head.item;
            tail = head = null;
            n--;
            return item;
        }

        Item item = head.item;
        head = head.next;
        head.prev = null;
        n--;
        return item;
    }

    // remove and return the item from the back
    public Item removeLast() {
        if (isEmpty()) throw new NoSuchElementException();

        if (n == 1) {
            Item item = tail.item;
            head = tail = null;
            n--;
            return item;
        }

        Item item = tail.item;
        tail = tail.prev;
        tail.next = null;
        n--;
        return item;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        return new ListIterator();
    }

    private class ListIterator implements Iterator<Item> {
        Node current = head;

        public boolean hasNext() {
            return current != null;
        }

        public Item next() {
            if (current == null) {
                throw new NoSuchElementException();
            }
            Item item = current.item;
            current = current.next;
            return item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing (required)
    public static void main(String[] args) {
        Deque<String> d = new Deque<>();

        d.addFirst("5");
        d.addLast("6");
        d.addFirst("4");
        d.addLast("7");
        d.addFirst("3");

        StdOut.println(d.size());
        StdOut.println(d.isEmpty());

        d.removeFirst();
        d.removeLast();

        Iterator<String> it = d.iterator();
        while (it.hasNext()) System.out.println(it.next());
    }
}