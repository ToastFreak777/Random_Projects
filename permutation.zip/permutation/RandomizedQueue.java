import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] array = (Item[]) new Object[2];
    private int n;

    // construct an empty randomized queue
    public RandomizedQueue() {
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return n == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return n;
    }

    // add the item
    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException();

        array[n++] = item;
        if (n == array.length) resizeArray(array.length * 2);
        moveValues();
    }

    private void resizeArray(int max) {
        Item[] newArray = (Item[]) new Object[max];
        for (int i = 0; i < n; i++) newArray[i] = array[i];
        array = newArray;
    }

    // remove and return a random item
    public Item dequeue() {
        if (n <= 0) throw new NoSuchElementException();

        //int rnd = randomize();
        Item item = array[--n];
        array[n] = null;

        if (n > 0 && n == array.length / 4) resizeArray(array.length / 2);
        return item;
    }

    // return a random item (but do not remove it)
    public Item sample() {
        if (n <= 0) throw new NoSuchElementException();
        return array[randomize()];
    }

    private int randomize() {
        return StdRandom.uniform(n);
    }

    private void moveValues() {
        int rnd = randomize();
        Item temp = array[rnd];
        array[rnd] = array[n - 1];
        array[n - 1] = temp;
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new ListIterator();
    }

    private class ListIterator implements Iterator<Item> {
        private int i;

        public boolean hasNext() {
            return array[i] != null;
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();

            Item item = array[i++];
            return item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<String> rq = new RandomizedQueue<>();
        StdOut.println(rq.isEmpty());
        rq.enqueue("1");
        rq.enqueue("2");
        rq.enqueue("3");
        rq.enqueue("4");
        StdOut.println(rq.size());
        rq.dequeue();
        StdOut.println(rq.sample());
        Iterator<String> IT = rq.iterator();

    }

}